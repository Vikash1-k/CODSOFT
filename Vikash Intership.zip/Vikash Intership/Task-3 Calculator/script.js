// script.js

let result = document.getElementById("result");

// Function to append numbers or operators to the display
function appendNumber(value) {
  result.value += value;
}

function appendOperator(value) {
  result.value += value;
}

// Function to clear the display
function clearDisplay() {
  result.value = "";
}

// Function to delete the last character
function deleteLast() {
  result.value = result.value.slice(0, -1);
}

// Function to calculate the result
function calculateResult() {
  try {
    result.value = eval(result.value);
  } catch (error) {
    result.value = "Error";
  }
}
